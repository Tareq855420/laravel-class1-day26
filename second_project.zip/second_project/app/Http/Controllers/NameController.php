<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NameController extends Controller
{
    protected $firstName = 'Arif';
    protected $lastName = 'Hasan';
    public function index()
    {
        return $this->firstName;
    }

    public function fullName()
    {
//        return $this->firstName.' '.$this->lastName;
//        return view('full-name', [
//            'firstName' => $this->firstName,
//            'lastName' => $this->lastName,
//        ]);

//        $firstName = $this->firstName;
//        $lastName = $this->lastName;
//        return view('full-name',compact(['firstName','lastName']));
    }
}
