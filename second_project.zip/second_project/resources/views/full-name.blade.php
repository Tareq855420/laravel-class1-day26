<h1>
   {{ $firstName }} {{ $lastName }}
</h1>

<h1>
    {{ $firstName.' '.$lastName }}
</h1>
