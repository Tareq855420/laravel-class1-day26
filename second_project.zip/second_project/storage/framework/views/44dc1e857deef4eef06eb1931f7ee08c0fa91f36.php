<h1>
   <?php echo e($firstName); ?> <?php echo e($lastName); ?>

</h1>

<h1>
    <?php echo e($firstName.' '.$lastName); ?>

</h1>
<?php /**PATH C:\xampp\htdocs\Tareq\second_project\resources\views/full-name.blade.php ENDPATH**/ ?>